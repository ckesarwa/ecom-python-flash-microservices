from flask import Flask, jsonify, request
import mysql.connector
import os
import requests

app = Flask(__name__)

# MySQL Configuration
app.config['DB_HOST'] = os.getenv('DB_HOST', 'localhost')  # Default to localhost if not set
app.config['DB_USER'] = os.getenv('DB_USER', 'root')
app.config['DB_PASSWORD'] = os.getenv('DB_PASSWORD', 'root_password')
app.config['DB_NAME'] = os.getenv('DB_NAME', 'orderdb')


# MySQL Connection
def get_db_connection():
    return mysql.connector.connect(
        host=app.config['DB_HOST'],
        user=app.config['DB_USER'],
        password=app.config['DB_PASSWORD'],
        database=app.config['DB_NAME']
    )

@app.route("/")
def home():
    return "Welcome to Order Microservice"

@app.route('/create_order', methods=['POST'])
def create_order():
    data = request.get_json()

    # Input validation
    if not data or 'product_id' not in data or 'quantity' not in data:
        return jsonify({"message": "Invalid request data"}), 400
    
    db = None
    cursor = None
    try:
        db = get_db_connection()
        cursor = db.cursor()

        cursor.execute("INSERT INTO orders (product_id, quantity) VALUES (%s, %s)", (int(data['product_id']), int(data['quantity'])))
        db.commit()

        # Prepare the payload to update stock
        update_payload = {
            "id": data['product_id'],
            "stock_change": -int(data['quantity'])  # Deduct stock based on order quantity
        }

        # Call the product-service to update the stock
        response = requests.post("http://product-service:5000/update_product_stock", json=update_payload)

        # Handle the response from product-service
        if response.status_code == 200:
            return jsonify({"message": "Order created and stock updated successfully"}), 201
        elif response.status_code == 400:
            return jsonify({"message": "Order created, but stock update failed", "error": response.json()}), 400
        elif response.status_code == 404:
            return jsonify({"message": "Order created, but product not found in product-service"}), 404
        else:
            return jsonify({"message": "Order created, but stock update encountered an error", "error": response.json()}), 500

    except Exception as e:
        return jsonify({"message": "An error occurred while creating the order", "error": str(e)}), 500
    finally:
        if cursor:
            cursor.close()
        if db:
            db.close()


@app.route('/orders', methods=['GET'])
def get_products():    
    db = get_db_connection()
    cursor = db.cursor(dictionary=True)
    cursor.execute("SELECT * FROM orders")
    products = cursor.fetchall()
    db.close()
    if products:
        return jsonify(products)
    else:
        return jsonify({"message": "Orders not found"}), 404
    
@app.route('/get_order/<int:order_id>', methods=['GET'])
def get_order(order_id):
    db = get_db_connection()
    cursor = db.cursor(dictionary=True)
    cursor.execute("SELECT * FROM orders WHERE id = %s", (order_id,))
    order = cursor.fetchone()
    return jsonify(order) if order else jsonify({"message": "Order not found"}), 404
    
if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5001)
