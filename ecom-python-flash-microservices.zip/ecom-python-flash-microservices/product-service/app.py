from flask import Flask, jsonify, request
import mysql.connector
import os

app = Flask(__name__)

# MySQL Configuration
app.config['DB_HOST'] = os.getenv('DB_HOST', 'localhost')  # Default to localhost if not set
app.config['DB_USER'] = os.getenv('DB_USER', 'root')
app.config['DB_PASSWORD'] = os.getenv('DB_PASSWORD', 'root_password')
app.config['DB_NAME'] = os.getenv('DB_NAME', 'productdb')


# MySQL Connection
def get_db_connection():
    return mysql.connector.connect(
        host=app.config['DB_HOST'],
        user=app.config['DB_USER'],
        password=app.config['DB_PASSWORD'],
        database=app.config['DB_NAME']
    )

@app.route("/")
def home():
    return "Welcome to Product Microservice"

@app.route('/products', methods=['GET'])
def get_products():    
    db = get_db_connection()
    cursor = db.cursor(dictionary=True)
    cursor.execute("SELECT * FROM products")
    products = cursor.fetchall()
    db.close()
    if products:
        return jsonify(products)
    else:
        return jsonify({"message": "Products not found"}), 404

@app.route('/add_product', methods=['POST'])
def add_product():
    data = request.get_json()
    db = get_db_connection()
    cursor = db.cursor()
    cursor.execute("INSERT INTO products (name, stock, price) VALUES (%s, %s, %s)", (data['name'], int(data['stock']) , float(data['price'])))
    db.commit()
    return jsonify({"message": "Product added"}), 201

@app.route('/get_product/<int:product_id>', methods=['GET'])
def get_product(product_id):
    db = get_db_connection()
    cursor = db.cursor(dictionary=True)
    cursor.execute("SELECT * FROM products WHERE id = %s", (product_id,))
    product = cursor.fetchone()
    if product:
        return jsonify(product)
    else:
        return jsonify({"message": "Product not found"}), 404

@app.route('/update_product_stock', methods=['POST'])
def update_product_stock():
    data = request.get_json()

    if not data or 'id' not in data or 'stock_change' not in data:
            return jsonify({"message": "Invalid request data"}), 400

    try:
        db = get_db_connection()
        cursor = db.cursor(dictionary=True)
        cursor.execute("SELECT * FROM products WHERE id = %s", (data['id'],))
        product = cursor.fetchone()
        if product:

            # Calculate the new stock
            new_stock = int(product['stock']) + int(data['stock_change'])
            
            if new_stock < 0:
                return jsonify({"message": "Stock cannot be negative"}), 400
            
            # Update the product stock
            cursor.execute("UPDATE products SET stock = %s WHERE id = %s", (new_stock, data['id']))
            db.commit()
            return jsonify({"message": "Product stock updated"}), 200
        else:
            return jsonify({"message": "Product not found"}), 404

    except Exception as e:
        return jsonify({"message": "An error occurred", "error": str(e)}), 500
    finally:
        if cursor:
            cursor.close()
        if db:
            db.close()

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
